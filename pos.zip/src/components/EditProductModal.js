import Image from "next/image";
import React, { useState } from "react";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const EditProductModal = ({ product, onClose, onUpdate }) => {
    const [name, setName] = useState(product.name);
    const [price, setPrice] = useState(product.price);
    const [stock, setStock] = useState(product.stock);
    const [img, setImg] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const handleImageChange = (e) => {
        const file = e.target.files[0];

        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setImg(reader.result);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validasi input
        if (price <= 0 || stock < 0) {
            toast.error("Price and stock must be positive values!");
            return;
        }
    
        const updatedProduct = { name, price, stock, img };
console.log("Product Data Before Send:", updatedProduct);

const response = await fetch(`/api/products/${product.id}`, {
    method: "PUT",
    headers: {
        "Content-Type": "application/json",
    },
    body: JSON.stringify(updatedProduct),
});

const responseBody = await response.json();
console.log("API Response Body:", responseBody);

    
        try {
            const response = await fetch(`/api/products/${product.id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(updatedProduct),
            });
    
            console.log("API Response Status:", response.status);
            const responseBody = await response.json();
            console.log("API Response Body:", responseBody);
    
            if (response.ok) {
                toast.success("Product updated successfully!");
                onUpdate();
                onClose();
            } else {
                toast.error("Failed to update product");
            }
        } catch (error) {
            console.error("Error updating product:", error);
            toast.error("Error updating product");
        } finally {
            setIsLoading(false);
        }
    };
    
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center">
            <div className="bg-white p-8 rounded-lg w-full max-w-md">
                <h2 className="text-2xl font-semibold text-center mb-4">Edit Product</h2>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label htmlFor="name" className="block text-lg">Product Name</label>
                        <input
                            type="text"
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full p-3 border rounded"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="price" className="block text-lg">Price</label>
                        <input
                            type="number"
                            id="price"
                            value={price}
                            onChange={(e) => setPrice(e.target.value)}
                            className="w-full p-3 border rounded"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="stock" className="block text-lg">Stock</label>
                        <input
                            type="number"
                            id="stock"
                            value={stock}
                            onChange={(e) => setStock(e.target.value)}
                            className="w-full p-3 border rounded"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="img" className="block text-lg">Product Image</label>
                        <input
                            type="file"
                            id="img"
                            accept="image/*"
                            onChange={handleImageChange}
                            className="w-full p-3 border rounded"
                        />
                        {img && (
                            <div className="mt-2">
                                <Image
                                    src={img}
                                    alt="Preview"
                                    className="object-cover"
                                    width={128}
                                    height={128}
                                />
                            </div>
                        )}
                    </div>
                    <div className="flex justify-between">
                        <button type="submit" className="bg-blue-500 text-white px-6 py-2 rounded" disabled={isLoading}>
                            {isLoading ? "Updating..." : "Update Product"}
                        </button>
                        <button
                            type="button"
                            onClick={onClose}
                            className="bg-gray-500 text-white px-6 py-2 rounded"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default EditProductModal;
